import os
import tempfile
import unittest

from app import app, init_db


class AuthFlowTests(unittest.TestCase):
    def setUp(self):
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        db_handle = tempfile.NamedTemporaryFile(
            dir=project_root,
            prefix="test_auth_",
            suffix=".db",
            delete=False,
        )
        db_handle.close()
        self.db_path = db_handle.name
        app.config["TESTING"] = True
        app.config["DATABASE"] = self.db_path
        init_db()
        self.client = app.test_client()

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def register_user(
        self,
        name="Test User",
        email="test@example.com",
        password="secret1",
        role="candidate",
        follow_redirects=True,
    ):
        return self.client.post(
            "/register",
            data={
                "name": name,
                "email": email,
                "password": password,
                "role": role,
            },
            follow_redirects=follow_redirects,
        )

    def login_user(self, email="test@example.com", password="secret1", follow_redirects=True):
        return self.client.post(
            "/",
            data={"email": email, "password": password},
            follow_redirects=follow_redirects,
        )

    def test_register_page_loads(self):
        response = self.client.get("/register")
        self.assertEqual(response.status_code, 200)

    def test_login_page_loads(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)

    def test_registration_success_redirects_to_login(self):
        response = self.register_user()
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Sign in", response.data)

    def test_registration_rejects_duplicate_email(self):
        self.register_user()
        response = self.register_user()
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Email exists", response.data)

    def test_registration_rejects_invalid_email(self):
        response = self.register_user(email="invalid-email")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Enter a valid email address", response.data)

    def test_registration_rejects_short_password(self):
        response = self.register_user(password="123")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Password must be at least 6 characters", response.data)

    def test_registration_rejects_invalid_role(self):
        response = self.register_user(role="admin")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Please select a valid role", response.data)

    def test_registration_rejects_blank_name(self):
        response = self.register_user(name="   ")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Name is required", response.data)

    def test_candidate_login_redirects_to_candidate_dashboard(self):
        self.register_user()
        response = self.login_user()
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Candidate Dashboard", response.data)

    def test_hr_login_redirects_to_hr_dashboard(self):
        self.register_user(email="hr@example.com", role="hr")
        response = self.login_user(email="hr@example.com")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"HR Dashboard", response.data)

    def test_login_rejects_invalid_password(self):
        self.register_user()
        response = self.login_user(password="wrongpass")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Invalid credentials", response.data)

    def test_login_rejects_unknown_email(self):
        response = self.login_user(email="unknown@example.com")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Invalid credentials", response.data)

    def test_login_requires_email_and_password(self):
        response = self.client.post(
            "/",
            data={"email": "", "password": ""},
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Email and password are required", response.data)


if __name__ == "__main__":
    unittest.main()
