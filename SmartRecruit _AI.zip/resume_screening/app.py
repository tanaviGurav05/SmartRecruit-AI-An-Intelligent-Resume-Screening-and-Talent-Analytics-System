from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
import os
import re
import zipfile
import xml.etree.ElementTree as ET
import pdfplumber
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

app = Flask(__name__)
app.secret_key = "secret123"

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["DATABASE"] = "database.db"
ALLOWED_RESUME_EXTENSIONS = {".pdf", ".docx"}

# -----------------------------
# DATABASE
# -----------------------------
def get_db_connection():
    return sqlite3.connect(app.config["DATABASE"])


def init_db():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        role TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS resumes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        filename TEXT,
        skills TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS jobs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        skills TEXT
    )""")

    conn.commit()
    conn.close()

init_db()


def validate_registration_form(name, email, password, role):
    if not name.strip():
        return "Name is required"
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return "Enter a valid email address"
    if len(password) < 6:
        return "Password must be at least 6 characters"
    if role not in {"candidate", "hr"}:
        return "Please select a valid role"
    return None

# -----------------------------
# SKILLS
# -----------------------------
skill_list = [
    "python","java","sql","machine learning","deep learning",
    "html","css","javascript","flask","django","data science",
    "selenium","api testing","automation testing","jira","postman",
    "json","php","node.js","react","network security","ethical hacking","cryptography"
]

# -----------------------------
# FUNCTIONS
# -----------------------------
def extract_text_pdf(path):
    text = ""
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() or ""
    return text.lower()


def extract_text_docx(path):
    text_parts = []
    with zipfile.ZipFile(path) as docx_zip:
        xml_content = docx_zip.read("word/document.xml")

    root = ET.fromstring(xml_content)
    namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    for node in root.findall(".//w:t", namespace):
        if node.text:
            text_parts.append(node.text)

    return " ".join(text_parts).lower()


def allowed_resume_file(filename):
    _, extension = os.path.splitext(filename.lower())
    return extension in ALLOWED_RESUME_EXTENSIONS


def extract_resume_text(path):
    _, extension = os.path.splitext(path.lower())
    if extension == ".pdf":
        return extract_text_pdf(path)
    if extension == ".docx":
        return extract_text_docx(path)
    raise ValueError("Unsupported resume format")

def normalize_skill(skill):
    return skill.strip().lower()


def extract_skills(text):
    text = text.lower()
    found_skills = []

    for skill in skill_list:
        pattern = r"(?<!\w)" + re.escape(skill.lower()) + r"(?!\w)"
        if re.search(pattern, text):
            found_skills.append(skill.lower())

    return sorted(set(found_skills))

def clean_skills(skills):
    return [normalize_skill(s) for s in skills if s.strip()]

def calculate_match(resume_skills, job_skills):
    resume_skills = clean_skills(resume_skills)
    job_skills = clean_skills(job_skills)

    match = set(resume_skills) & set(job_skills)
    score = (len(match) / len(job_skills)) * 100 if job_skills else 0
    missing = list(set(job_skills) - set(resume_skills))

    return round(score,2), missing


def build_job_description(manual_description, uploaded_description):
    parts = [manual_description.strip(), uploaded_description.strip()]
    return "\n".join(part for part in parts if part).strip().lower()


def get_job_skills(job_row):
    description = job_row[2] or ""
    stored_skills = job_row[3] or ""
    parsed_skills = clean_skills(stored_skills.split(","))
    known_skills = {skill.lower() for skill in skill_list}

    if not parsed_skills:
        return extract_skills(description)

    valid_skills = [skill for skill in parsed_skills if skill in known_skills]
    if valid_skills and len(valid_skills) == len(parsed_skills):
        return valid_skills

    return extract_skills(description)


def annotate_vertical_bars(bars, suffix="", precision=0):
    for bar in bars:
        height = bar.get_height()
        if precision == 0:
            label = f"{int(round(height))}{suffix}"
        else:
            label = f"{height:.{precision}f}{suffix}"

        plt.text(
            bar.get_x() + bar.get_width() / 2,
            height + max(0.04, height * 0.02),
            label,
            ha="center",
            va="bottom",
            fontsize=9,
            fontweight="bold",
        )


def add_chart_note(note):
    plt.gca().text(
        0.02,
        0.98,
        note,
        transform=plt.gca().transAxes,
        ha="left",
        va="top",
        fontsize=9,
        bbox={"boxstyle": "round,pad=0.35", "facecolor": "#fff7e6", "edgecolor": "#d6b98f"},
    )


def save_pie_chart(filename, title, labels, values, note, colors=None):
    plt.figure(figsize=(7,5))
    safe_values = [value if value > 0 else 0.01 for value in values]
    plt.pie(
        safe_values,
        labels=labels,
        autopct="%1.1f%%",
        startangle=140,
        colors=colors,
        wedgeprops={"edgecolor": "white", "linewidth": 2},
        textprops={"fontsize": 9},
    )
    plt.title(title)
    add_chart_note(note)
    plt.axis("equal")
    plt.tight_layout()
    plt.savefig(os.path.join("static", filename))
    plt.close()


def performance_band(score):
    if score >= 80:
        return "Strong fit"
    if score >= 60:
        return "Good fit"
    if score >= 40:
        return "Moderate fit"
    return "Needs improvement"


course_recommendations = {
    "python": "Python for Everybody or an intermediate Python developer path",
    "java": "Object-oriented Java programming and DSA practice",
    "sql": "SQL for data analysis and database querying fundamentals",
    "html": "Modern HTML and semantic web structure basics",
    "css": "Responsive CSS and Flexbox/Grid practice",
    "javascript": "JavaScript fundamentals with DOM and ES6 concepts",
    "react": "React fundamentals and component-based UI building",
    "node.js": "Node.js backend fundamentals and REST API basics",
    "flask": "Flask web development and REST API project work",
    "django": "Django full-stack web development fundamentals",
    "php": "PHP backend development basics",
    "json": "Working with JSON APIs and data exchange formats",
    "network security": "Network security foundations and threat analysis",
    "ethical hacking": "Ethical hacking basics and penetration testing labs",
    "cryptography": "Cryptography fundamentals and secure systems basics",
}


def build_candidate_recommendations(latest_analysis):
    if not latest_analysis or not latest_analysis.get("results"):
        return [], []

    missing_frequency = {}
    for result in latest_analysis["results"]:
        for skill in result["missing"]:
            missing_frequency[skill] = missing_frequency.get(skill, 0) + 1

    top_missing = [skill for skill, _ in sorted(missing_frequency.items(), key=lambda item: item[1], reverse=True)[:4]]
    recommendations = [
        {
            "skill": skill.title(),
            "course": course_recommendations.get(skill, f"A focused learning path for {skill.title()}"),
        }
        for skill in top_missing
    ]

    score_tips = []
    if latest_analysis["best_result"] and latest_analysis["best_result"]["score"] < 60:
        score_tips.append("Add more job-specific technical skills to your resume summary and skills section.")
    score_tips.append("Tailor your resume keywords to match the strongest target job description before uploading.")
    score_tips.append("Move your most relevant project, internship, or tool experience closer to the top of the resume.")
    if top_missing:
        score_tips.append(f"Focus first on {', '.join(skill.title() for skill in top_missing[:2])} to improve your next upload fastest.")

    return recommendations, score_tips

# -----------------------------
# LOGIN
# -----------------------------
@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"]

        if not email or not password:
            flash("Email and password are required")
            return render_template("login.html")

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email=? AND password=?", (email,password))
        user = cur.fetchone()
        conn.close()

        if user:
            session["user_id"] = user[0]
            session["role"] = user[4]
            return redirect("/candidate" if user[4]=="candidate" else "/hr")
        else:
            flash("Invalid credentials")

    return render_template("login.html")

# -----------------------------
# REGISTER
# -----------------------------
@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip()
        password = request.form["password"]
        role = request.form["role"]

        error = validate_registration_form(name, email, password, role)
        if error:
            flash(error)
            return redirect("/register")

        conn = get_db_connection()
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO users(name,email,password,role) VALUES (?,?,?,?)",
                        (name,email,password,role))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            flash("Email exists")
            return redirect("/register")

        conn.close()
        return redirect("/")

    return render_template("register.html")

# -----------------------------
# CANDIDATE DASHBOARD
# -----------------------------
@app.route("/candidate", methods=["GET","POST"])
def candidate():

    if request.method == "POST":
        files = request.files.getlist("resume")

        conn = get_db_connection()
        cur = conn.cursor()
        uploaded_any = False

        for file in files:
            if file.filename == "":
                continue

            if not allowed_resume_file(file.filename):
                flash(f"{file.filename} was skipped. Only PDF and DOCX resumes are allowed.")
                continue

            path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(path)

            try:
                text = extract_resume_text(path)
            except Exception:
                if os.path.exists(path):
                    os.remove(path)
                flash(f"{file.filename} could not be analyzed. Please upload a valid PDF or DOCX resume.")
                continue

            skills = extract_skills(text)

            cur.execute("INSERT INTO resumes(user_id,filename,skills) VALUES (?,?,?)",
                        (session["user_id"], file.filename, ",".join(skills)))
            uploaded_any = True

        conn.commit()
        conn.close()

        if not uploaded_any:
            flash("No valid resumes were uploaded. Please upload PDF or DOCX resume files only.")

    conn = get_db_connection()
    cur = conn.cursor()

    # ✅ ONLY CURRENT USER DATA
    cur.execute("SELECT name FROM users WHERE id=?", (session["user_id"],))
    user_row = cur.fetchone()
    candidate_name = user_row[0] if user_row else "Candidate"

    cur.execute("SELECT * FROM resumes WHERE user_id=? ORDER BY id ASC", (session["user_id"],))
    resumes = cur.fetchall()

    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()

    conn.close()

    resume_analyses = []

    for index, r in enumerate(resumes, start=1):
        resume_label = f"Upload {index}"
        resume_skills = r[3].split(",")
        resume_results = []

        for job in jobs:
            job_skills = get_job_skills(job)
            score, missing = calculate_match(resume_skills, job_skills)
            matched_count = len(job_skills) - len(missing)

            suggestions = []
            if score > 60:
                suggestions = [f"Learn {m}" for m in missing]

            resume_results.append({
                "candidate": candidate_name,
                "resume_label": resume_label,
                "title": job[1],
                "score": score,
                "missing": missing,
                "matched_count": matched_count,
                "missing_count": len(missing),
                "suggestions": suggestions,
                "band": performance_band(score),
            })

        resume_results = sorted(resume_results, key=lambda x: x["score"], reverse=True)
        best_result = resume_results[0] if resume_results else None

        resume_analyses.append({
            "resume_id": r[0],
            "resume_label": resume_label,
            "filename": r[2],
            "skills": clean_skills(r[3].split(",")),
            "results": resume_results,
            "best_result": best_result,
            "average_score": round(sum(item["score"] for item in resume_results) / len(resume_results), 2) if resume_results else 0,
        })

    latest_analysis = resume_analyses[-1] if resume_analyses else None
    history_items = []
    previous_best_score = None

    for analysis in resume_analyses:
        best_score = analysis["best_result"]["score"] if analysis["best_result"] else 0
        delta = None if previous_best_score is None else round(best_score - previous_best_score, 2)
        history_items.append({
            "resume_id": analysis["resume_id"],
            "resume_label": analysis["resume_label"],
            "filename": analysis["filename"],
            "best_role": analysis["best_result"]["title"] if analysis["best_result"] else "No jobs available",
            "best_score": best_score,
            "average_score": analysis["average_score"],
            "delta": delta,
            "band": performance_band(best_score),
        })
        previous_best_score = best_score

    if latest_analysis and latest_analysis["results"]:
        top_roles = latest_analysis["results"][:5]
        remaining_roles = latest_analysis["results"][5:]

        role_names = [item["title"] for item in top_roles]
        role_scores = [item["score"] for item in top_roles]

        if remaining_roles:
            role_names.append("Other roles")
            role_scores.append(sum(item["score"] for item in remaining_roles))

        plt.figure(figsize=(9,6))
        pie_scores = [score if score > 0 else 0.01 for score in role_scores]
        colors = ["#c46a2d", "#d78b4e", "#e8ab72", "#7ea172", "#4f7c64", "#b8b0a5"][:len(role_names)]
        explode = [0.08] + [0] * (len(role_names) - 1)
        wedges, texts, autotexts = plt.pie(
            pie_scores,
            labels=None,
            autopct=lambda pct: f"{pct:.1f}%" if pct >= 6 else "",
            startangle=140,
            colors=colors,
            explode=explode,
            pctdistance=0.8,
            wedgeprops={"edgecolor": "white", "linewidth": 2, "width": 0.42},
            textprops={"fontsize": 9},
        )
        plt.legend(
            wedges,
            [f"{name} ({score:.1f}%)" for name, score in zip(role_names, role_scores)],
            title="Role fit summary",
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),
            frameon=False,
        )
        plt.title("Latest Upload Role Distribution")
        add_chart_note("Top roles are shown directly. Smaller roles are grouped to reduce overlap.")
        plt.axis("equal")
        plt.tight_layout()
        plt.savefig("static/match_chart.png")
        plt.close()

        job_matched = {}
        job_missing = {}

        for result in latest_analysis["results"]:
            job_matched.setdefault(result["title"], []).append(result["matched_count"])
            job_missing.setdefault(result["title"], []).append(result["missing_count"])

        job_names = list(job_matched.keys())
        avg_matched = [sum(job_matched[j]) / len(job_matched[j]) for j in job_names]
        avg_missing = [sum(job_missing[j]) / len(job_missing[j]) for j in job_names]

        plt.figure(figsize=(8,5))
        bars1 = plt.bar(job_names, avg_matched, color="green", label="Matched")
        bars2 = plt.bar(job_names, avg_missing, bottom=avg_matched, color="red", label="Missing")

        plt.xticks(rotation=30)
        plt.title("Skill Gap Analysis (Latest Upload)")
        plt.xlabel("Job Roles")
        plt.ylabel("No. of Skills")
        plt.legend()
        add_chart_note("This skill gap view is based on the newest uploaded resume only.")

        for bar in bars1:
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height()/2,
                     int(bar.get_height()), ha='center', color='white')

        for bar in bars2:
            plt.text(bar.get_x() + bar.get_width()/2,
                     bar.get_y() + bar.get_height()/2,
                     int(bar.get_height()), ha='center', color='white')

        plt.tight_layout()
        plt.savefig("static/skill_gap.png")
        plt.close()

    if history_items:
        labels = [item["resume_label"] for item in history_items]
        scores = [item["best_score"] for item in history_items]

        plt.figure(figsize=(8,5))
        bars = plt.bar(labels, scores, color="#c46a2d")
        plt.title("Resume Improvement History")
        plt.xlabel("Uploads")
        plt.ylabel("Best Match Score (%)")
        annotate_vertical_bars(bars, suffix="%")
        add_chart_note("Use this chart to see whether newer uploads improved your strongest job fit.")
        plt.ylim(0, max(scores) + 15 if scores else 10)
        plt.tight_layout()
        plt.savefig("static/history_chart.png")
        plt.close()

    recommended_courses, score_tips = build_candidate_recommendations(latest_analysis)

    return render_template("candidate_dashboard.html",
                           latest_analysis=latest_analysis,
                           history_items=history_items,
                           resume=resumes,
                           candidate_name=candidate_name,
                           recommended_courses=recommended_courses,
                           score_tips=score_tips)


@app.route("/candidate/delete/<int:resume_id>", methods=["POST"])
def delete_resume(resume_id):
    if "user_id" not in session or session.get("role") != "candidate":
        flash("Please log in as a candidate to manage uploads.")
        return redirect("/")

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT filename FROM resumes WHERE id=? AND user_id=?", (resume_id, session["user_id"]))
    row = cur.fetchone()

    if not row:
        conn.close()
        flash("Resume upload not found.")
        return redirect("/candidate")

    filename = row[0]
    cur.execute("DELETE FROM resumes WHERE id=? AND user_id=?", (resume_id, session["user_id"]))
    conn.commit()

    cur.execute("SELECT COUNT(*) FROM resumes WHERE filename=?", (filename,))
    remaining_count = cur.fetchone()[0]
    conn.close()

    if remaining_count == 0:
        file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        if os.path.exists(file_path):
            os.remove(file_path)

    flash("Uploaded resume removed successfully.")
    return redirect("/candidate")
# -----------------------------
# HR DASHBOARD
# -----------------------------
@app.route("/hr", methods=["GET","POST"])
def hr():

    selected_skill = request.args.get("skill", "python")

    # -----------------------------
    # ADD JOB
    # -----------------------------
    if request.method == "POST":
        title = request.form["title"]
        description = request.form.get("description", "")
        file = request.files.get("jd_file")
        uploaded_description = ""

        if file and file.filename:
            path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(path)
            uploaded_description = extract_text_pdf(path)

        full_description = build_job_description(description, uploaded_description)
        if not full_description:
            flash("Add a job description or upload a job description file before posting.")
            return redirect("/hr")

        skills = extract_skills(full_description)
        if not skills:
            flash("No supported skills were detected in the job description. Please include relevant technical skills.")
            return redirect("/hr")

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("INSERT INTO jobs(title,description,skills) VALUES (?,?,?)",
                    (title, full_description, ",".join(skills)))
        conn.commit()
        conn.close()

    # -----------------------------
    # FETCH DATA
    # -----------------------------
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()

    cur.execute("""
        SELECT resumes.id, resumes.user_id, resumes.filename, resumes.skills, users.name
        FROM resumes
        LEFT JOIN users ON resumes.user_id = users.id
    """)
    resumes = cur.fetchall()

    conn.close()

    # -----------------------------
    # TOP CANDIDATES (>60%)
    # -----------------------------
    top_candidates = []

    for r in resumes:
        candidate_name = r[4] if r[4] else r[2]
        resume_skills = r[3].split(",")

        for job in jobs:
            job_skills = get_job_skills(job)

            score, _ = calculate_match(resume_skills, job_skills)

            if score > 60:
                top_candidates.append({
                    "name": candidate_name,
                    "job": job[1],
                    "score": score,
                    "skills": resume_skills
                })

    top_candidates = sorted(top_candidates, key=lambda x: x["score"], reverse=True)

    # -----------------------------
    # 📊 GRAPH 1: JOB vs HIGHEST SCORE
    # -----------------------------
    job_max_score = {}

    for job in jobs:
        job_title = job[1]
        job_skills = get_job_skills(job)

        max_score = 0

        for r in resumes:
            resume_skills = r[3].split(",")

            score, _ = calculate_match(resume_skills, job_skills)

            if score > max_score:
                max_score = score

        job_max_score[job_title] = max_score

    if job_max_score:
        job_names = list(job_max_score.keys())
        scores = list(job_max_score.values())

        plt.figure(figsize=(8,5))
        bars = plt.bar(job_names, scores, color="#7b4bb3")

        plt.xticks(rotation=30)
        plt.title("Highest Candidate Score per Job")
        plt.xlabel("Job Roles")
        plt.ylabel("Score (%)")
        annotate_vertical_bars(bars, suffix="%")
        add_chart_note("Each bar shows the best candidate score currently available for that job.")
        plt.ylim(0, max(scores) + 15)

        plt.tight_layout()
        plt.savefig("static/chart.png")
        plt.close()

    # -----------------------------
    # 📊 GRAPH 2: DYNAMIC SKILL COMPARISON (UNCHANGED)
    # -----------------------------
    candidate_names = []
    skill_presence = []

    for r in resumes:
        name = r[2]
        skills = r[3].split(",")

        candidate_names.append(name)
        skill_presence.append(1 if selected_skill in skills else 0)

    if candidate_names:
        plt.figure(figsize=(8,5))
        bars = plt.bar(candidate_names, skill_presence, color="#2f855a")
        plt.xticks(rotation=30)
        plt.title(f"{selected_skill.upper()} Skill Comparison")
        plt.xlabel("Candidates")
        plt.ylabel("1 = Has Skill, 0 = No Skill")
        annotate_vertical_bars(bars)
        add_chart_note("1 means the selected skill was detected in the resume. 0 means it was not detected.")
        plt.ylim(0, 1.4)
        plt.tight_layout()
        plt.savefig("static/dynamic_chart.png")
        plt.close()

    return render_template("hr_dashboard.html",
                           jobs=jobs,
                           top_candidates=top_candidates,
                           selected_skill=selected_skill,
                           skill_list=skill_list)

# -----------------------------
# RUN
# -----------------------------
if __name__ == "__main__":
    if not os.path.exists("uploads"):
        os.makedirs("uploads")
    app.run(debug=True)
