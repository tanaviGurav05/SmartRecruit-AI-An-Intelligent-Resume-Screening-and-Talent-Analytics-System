from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
import os
import pdfplumber
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

app = Flask(__name__)
app.secret_key = "secret123"

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# -----------------------------
# DATABASE
# -----------------------------
def init_db():
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        role TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS resumes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        filename TEXT,
        skills TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS jobs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        skills TEXT
    )""")

    conn.commit()
    conn.close()

init_db()

# -----------------------------
# SKILLS
# -----------------------------
skill_list = [
    "python","java","sql","machine learning","deep learning",
    "html","css","javascript","flask","django","data science"
]

# -----------------------------
# FUNCTIONS
# -----------------------------
def extract_text_pdf(path):
    text = ""
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() or ""
    return text.lower()

def extract_skills(text):
    return list(set([s for s in skill_list if s in text]))

def calculate_match(resume_skills, job_skills):
    match = set(resume_skills) & set(job_skills)
    score = (len(match) / len(job_skills)) * 100 if job_skills else 0
    missing = list(set(job_skills) - set(resume_skills))
    return round(score,2), list(match), missing

# -----------------------------
# LOGIN
# -----------------------------
@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email=? AND password=?", (email,password))
        user = cur.fetchone()
        conn.close()

        if user:
            session["user_id"] = user[0]
            session["role"] = user[4]
            return redirect("/candidate" if user[4]=="candidate" else "/hr")
        else:
            flash("Invalid credentials")

    return render_template("login.html")

# -----------------------------
# REGISTER
# -----------------------------
@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        role = request.form["role"]

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO users(name,email,password,role) VALUES (?,?,?,?)",
                        (name,email,password,role))
            conn.commit()
        except:
            flash("Email exists")
            return redirect("/register")

        conn.close()
        return redirect("/")

    return render_template("register.html")

# -----------------------------
# CANDIDATE DASHBOARD
# -----------------------------
@app.route("/candidate", methods=["GET","POST"])
def candidate():
    if request.method == "POST":
        file = request.files["resume"]

        path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(path)

        text = extract_text_pdf(path)
        skills = extract_skills(text)

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()

        cur.execute("DELETE FROM resumes WHERE user_id=?", (session["user_id"],))
        cur.execute("INSERT INTO resumes(user_id,filename,skills) VALUES (?,?,?)",
                    (session["user_id"], file.filename, ",".join(skills)))

        conn.commit()
        conn.close()

    conn = sqlite3.connect("database.db")
    cur = conn.cursor()

    cur.execute("SELECT * FROM resumes WHERE user_id=?", (session["user_id"],))
    resume = cur.fetchone()

    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()

    conn.close()

    results = []

    if resume:
        resume_skills = resume[3].split(",")

        for job in jobs:
            job_skills = job[3].split(",")
            score, match, missing = calculate_match(resume_skills, job_skills)

            suggestions = []
            if score < 75:
                suggestions = [f"Learn {m}" for m in missing]

            results.append({
                "title": job[1],
                "score": score,
                "match": match,
                "missing": missing,
                "suggestions": suggestions
            })

        results = sorted(results, key=lambda x: x["score"], reverse=True)

        # 📊 MATCH SCORE GRAPH
        job_names = [r["title"] for r in results]
        scores = [r["score"] for r in results]

        plt.figure()
        plt.bar(job_names, scores)
        plt.xticks(rotation=30)
        plt.title("Job Match Score")
        plt.savefig("static/match_chart.png")
        plt.close()

        # 🧠 SKILL GAP GRAPH
        matched_counts = [len(r["match"]) for r in results]
        missing_counts = [len(r["missing"]) for r in results]

        plt.figure()
        plt.bar(job_names, matched_counts, label="Matched")
        plt.bar(job_names, missing_counts, bottom=matched_counts, label="Missing")
        plt.legend()
        plt.title("Skill Gap Analysis")
        plt.savefig("static/skill_gap.png")
        plt.close()

    return render_template("candidate_dashboard.html",
                           results=results,
                           resume=resume)

# -----------------------------
# -----------------------------
# HR DASHBOARD
# -----------------------------
@app.route("/hr", methods=["GET","POST"])
def hr():

    selected_skill = request.args.get("skill", "python")

    # -----------------------------
    # ADD JOB
    # -----------------------------
    if request.method == "POST":
        title = request.form["title"]
        description = request.form.get("description", "")
        file = request.files.get("jd_file")

        if file and file.filename:
            path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(path)
            description += extract_text_pdf(path)

        skills = extract_skills(description)

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        cur.execute("INSERT INTO jobs(title,description,skills) VALUES (?,?,?)",
                    (title, description, ",".join(skills)))
        conn.commit()
        conn.close()

    # -----------------------------
    # FETCH DATA
    # -----------------------------
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()

    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()

    cur.execute("SELECT * FROM resumes")
    resumes = cur.fetchall()

    cur.execute("SELECT * FROM users WHERE role='candidate'")
    users = cur.fetchall()

    conn.close()

    # -----------------------------
    # TOP CANDIDATES
    # -----------------------------
    top_candidates = []

    for r in resumes:
        user_id = r[1]
        resume_skills = r[3].split(",")

        name = next((u[1] for u in users if u[0] == user_id), "")

        best_score = 0
        best_job = ""

        for job in jobs:
            job_skills = job[3].split(",")
            score, _, _ = calculate_match(resume_skills, job_skills)

            if score > best_score:
                best_score = score
                best_job = job[1]

        if best_score >= 60:
            top_candidates.append({
                "name": name,
                "job": best_job,
                "score": best_score,
                "skills": resume_skills
            })

    top_candidates = sorted(top_candidates, key=lambda x: x["score"], reverse=True)

    # -----------------------------
    # 📊 ORIGINAL SKILL ANALYTICS (KEEP SAME)
    # -----------------------------
    skill_count = {}

    for r in resumes:
        for s in r[3].split(","):
            if s:
                skill_count[s] = skill_count.get(s, 0) + 1

    if skill_count:
        plt.figure()
        plt.bar(skill_count.keys(), skill_count.values())
        plt.xticks(rotation=45)
        plt.title("Candidate Skills Analytics")
        plt.savefig("static/chart.png")
        plt.close()

    # -----------------------------
    # 🔥 NEW DYNAMIC SKILL GRAPH
    # -----------------------------
    candidate_names = []
    skill_presence = []

    for r in resumes:
        user_id = r[1]
        skills = r[3].split(",")

        name = next((u[1] for u in users if u[0] == user_id), "")

        candidate_names.append(name)
        skill_presence.append(1 if selected_skill in skills else 0)

    if candidate_names:
        plt.figure()
        plt.bar(candidate_names, skill_presence)
        plt.xticks(rotation=30)
        plt.title(f"{selected_skill.upper()} Skill Comparison")
        plt.ylabel("1 = Has Skill, 0 = No Skill")
        plt.savefig("static/dynamic_chart.png")
        plt.close()

    return render_template("hr_dashboard.html",
                           jobs=jobs,
                           top_candidates=top_candidates,
                           selected_skill=selected_skill,
                           skill_list=skill_list)
# RUN
# -----------------------------
if __name__ == "__main__":
    if not os.path.exists("uploads"):
        os.makedirs("uploads")
    app.run(debug=True)